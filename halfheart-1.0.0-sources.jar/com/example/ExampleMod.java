package com.example;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_1324;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExampleMod implements ModInitializer {

	public static final String MOD_ID = "modid";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {

		LOGGER.info("Half heart mode loaded!");

		ServerTickEvents.END_SERVER_TICK.register(server -> {

			for (class_3222 player : server.method_3760().method_14571()) {

				// ЕСЛИ ИГРОК МЁРТВ — НЕ ТРОГАЕМ ЕГО
				if (!player.method_5805()) {
					continue;
				}

				class_1324 maxHealth = player.method_5996(class_5134.field_23716);

				if (maxHealth != null) {

					// максимум 1 HP
					if (maxHealth.method_6201() != 1.0D) {
						maxHealth.method_6192(1.0D);
					}

					// ставим 1 HP только если жив
					if (player.method_6032() > 1.0F) {
						player.method_6033(1.0F);
					}
				}
			}

		});

	}
}